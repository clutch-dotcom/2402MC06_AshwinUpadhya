#include "types.h"
#include "stat.h"
#include "user.h"

int
main(int argc, char *argv[])
{
  char *p = sbrk(4096);
  if(p == (char*)-1){
    printf(2, "sbrk failed\n");
    exit();
  }

  // atore 'A' in the newly allocated page-aligned page
  *p = 'A';
  printf(1, "Initial value: %c\n", *p);

  // call mprotect and verify reading still works
  if(mprotect(p, 1) < 0){
    printf(2, "FAIL: mprotect failed on valid page\n");
    exit();
  }
  printf(1, "read after mprotect: %c (PASS)\n", *p);

 //fork a child that attempts to write to the protected page
  int pid = fork();
  if(pid < 0){
    printf(2, "fork failed\n");
    exit();
  }
  if(pid == 0){
    printf(1, "child attempting write to protected page \n");
    *p = 'B';  // triggers page fault (T_PGFLT, err & 2) -> kernel kills child
    printf(2, "FAIL: Child survived write to protected page\n");
    exit();
  } else {
    wait();
    printf(1, "parent survived; value is still: %c (PASS)\n", *p);
  }

  //unprotect after up succeeds
  if(munprotect(p, 1) < 0){
    printf(2, "FAIL: munprotect failed\n");
    exit();
  }
  *p = 'C';
  printf(1, "vaalue after munprotect and write: %c (PASS)\n", *p);

  // invalid arguments for mprotect
  int r1 = mprotect(p + 1, 1);        
  int r2 = mprotect(p, 0);            
  int r3 = mprotect(p, -2);           
  int r4 = mprotect(p, 2);           
  printf(1, "error checks(should be -1 ;) ) : unaligned=%d, len0=%d, negLen=%d, outOfBounds=%d\n",
         r1, r2, r3, r4);


  exit();
}

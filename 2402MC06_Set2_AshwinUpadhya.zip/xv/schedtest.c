#include "types.h"
#include "stat.h"
#include "user.h"

void cpu_bound_work(void){
  volatile int x = 0;
  (void)x;
  for (int i = 0; i < 60000000; i++) {
    x += (i * 3) % 7;
  }
}

int main(void){
    int u = setpriority(getpid(), 1);
    (void)u;

    for(int i = 1; i<4; i++){
        int pid = fork();

        if(pid == 0){
            int mypid = getpid();
            setpriority(mypid, i*5);                                    //eventhough question asked for set_priority, i implemented the syscall as setpriority.

            printf(1, "\nchild with pid %d and priority %d started\n", mypid, i*5);

            cpu_bound_work();
             printf(1, "\nchild with pid %d and priority %d finished\n", mypid, i*5);

            exit();
        }
    }

    wait();
    wait();
    wait();

    printf(1, "parent finished");

    exit();
}